package goldenfile

import (
	"flag"
)

var Update = flag.String("update", "", "name of test to update")
